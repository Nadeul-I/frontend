<template>
    <router-view></router-view>
</template>

<script>
export default {
    name: 'AppMyPage'
}
</script>

<style>

</style>